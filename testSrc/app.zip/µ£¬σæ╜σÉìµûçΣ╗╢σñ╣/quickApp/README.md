## 快速上手

您可通过运行 `npm run start` 后，使用快应用引擎扫描二维码快速开发。

## 了解更多

你可以通过我们的[官方文档](https://doc.quickapp.cn/)熟悉和了解快应用。

可以通过我们[快应用官方示例项目](https://github.com/quickappcn/sample)，快速掌握
api 和组件的用法

对我们有什么意见，建议或者 bug，可以在这里反馈
https://github.com/quickappcn/issues

// npm install -g hap-toolkit
//cd web_project，  hap -v  ，hap init quickApp
// hap update --force
// npm i    
// npm run server 
// npm run build   生成rpk